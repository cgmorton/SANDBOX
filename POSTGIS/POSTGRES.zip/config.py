# Import static files
# We use a common statics file for python and javascript (statics.json)
from json import load

global statics
with open('statics.json', 'r') as fin:
    statics = load(fin)

# Bucket parameters
'''
BUCKET_NAME = 'gs://cloudsql-temp'
STORAGE_BUCKET = 'cloudsql-temp'
STORAGE_BUCKET_URL = 'https://storage.googleapis.com/' + STORAGE_BUCKET
# STORAGE_BUCKET_URL = 'https://console.cloud.google.com/storage/browser/' + STORAGE_BUCKET
'''
GEO_BUCKET_URL = 'https://storage.googleapis.com/roses-geojson/'
# https://console.cloud.google.com/storage/browser/roses-geojson?project=nasa-roses
GEO_BUCKET_NAME = 'roses-geojson'
DATA_BUCKET_URL = 'https://storage.googleapis.com/roses-data/'
# https://console.cloud.google.com/storage/browser/roses-data?project=nasa-roses
DATA_BUCKET_NAME = 'roses_data'
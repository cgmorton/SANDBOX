import os
import time
from sqlalchemy import create_engine
import db_methods
import config


#######################################
# END OpenET database tables
#######################################

if __name__ == '__main__':
    # start_time = time.time()
    DB_USER = os.environ['MY_DB_USER']
    DB_PASSWORD = os.environ['MY_DB_PASSWORD']
    DB_PORT = os.environ['MY_DB_PORT']
    DB_HOST = os.environ['MY_DB_HOST']
    DB_NAME = os.environ['MY_DB_NAME']

    db_string = "postgresql+psycopg2://" + DB_USER + ":" + DB_PASSWORD
    db_string += "@" + DB_HOST +  ":" + str(DB_PORT) + '/' + DB_NAME
    engine = create_engine(db_string)

    db_methods.Base.metadata.drop_all(engine)
    db_methods.Base.metadata.create_all(engine)

    start_time = time.time()

    # print(Base.metadata.sorted_tables)
    datasets = ['SSEBop']
    user_id = 0
    regions = ["Mason", "US_states_west_500k", "US_counties_west_500k", "Mason", "CentralValley_15"]
    for rgn in regions[4:5]:
        for ds in datasets:
            s_year = int(config.statics['all_year'][ds][0])
            e_year = int(config.statics['all_year'][ds][1])
            years = range(s_year, e_year)
            for year_int in years[0:1]:
                year = str(year_int)
                DB_Util = db_methods.database_Util(rgn, ds, year, user_id, engine)
                DB_Util.add_data_to_db()
                db_str = '/'.join([rgn, ds, year])
                print('Uploaded: ' + db_str)
    print("--- %s seconds ---" % (str(time.time() - start_time)))
    print("--- %s minutes ---" % (str((time.time() - start_time) / 60.0)))
    print("--- %s hours ---" % (str((time.time() - start_time) / 3600.0)))
